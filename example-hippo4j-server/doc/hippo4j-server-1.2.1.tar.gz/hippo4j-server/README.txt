
初始化
1. 数据库执行 SQL 脚本 /conf/hippo4j_manager.sql
2. 修改数据库相关信息 /conf/application.properties


启动命令
Mac Linux 执行 sh ./bin/startup.sh
Windows 执行 ./bin/startup.cmd

启动成功后，访问 localhost:6691/index.html
用户名密码：admin 123456
